import DashboardHeader from "@/components/dashboard/dashboard-header"

export default function ExpensesHeader() {
  return <DashboardHeader />
}

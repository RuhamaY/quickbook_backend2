import DashboardHeader from "@/components/dashboard/dashboard-header"

export default function TransactionsHeader() {
  return <DashboardHeader />
}

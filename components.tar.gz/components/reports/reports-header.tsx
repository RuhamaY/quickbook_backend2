import DashboardHeader from "@/components/dashboard/dashboard-header"

export default function ReportsHeader() {
  return <DashboardHeader />
}

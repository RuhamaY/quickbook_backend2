import LandingPage from "@/components/landing-page"

export default function LoginPage() {
  return <LandingPage />
}
